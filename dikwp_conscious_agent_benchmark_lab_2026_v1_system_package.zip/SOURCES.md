Design basis: WCAC 2026 forecast report supplied by user; NIST AI RMF; EU GPAI Code; OECD AI Principles; AISI Inspect; OpenAI evals; DIKWP TransitTrustGraph and BusPulse reports.
