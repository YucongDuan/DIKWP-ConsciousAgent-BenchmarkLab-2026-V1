# DIKWP ConsciousAgent BenchmarkLab 2026 V1

Standalone offline platform for trustworthy auditable agents, artificial-consciousness-related capability indicators and DIKWP open benchmark. Open `index.html`. No network or model API required.
