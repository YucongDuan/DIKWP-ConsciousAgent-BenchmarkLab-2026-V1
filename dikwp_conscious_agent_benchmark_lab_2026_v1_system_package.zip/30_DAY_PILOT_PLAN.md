Week 1 vocabulary and Run Contract. Week 2 DIKWP matrix and Trace. Week 3 ACI and 3-No judge calibration. Week 4 v0.1 benchmark and Passport.
