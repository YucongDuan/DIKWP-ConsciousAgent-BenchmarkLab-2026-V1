#!/usr/bin/env python3
from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parents[1]
patterns=[r'\brequests\.',r'\burllib\.request',r'\bsocket\.',r'\beval\(',r'\bexec\(',r'localStorage',r'navigator\.mediaDevices']
find=[]
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.py','.html','.json'} and p.name!='static_boundary_audit.py':
        text=p.read_text(encoding='utf-8',errors='ignore')
        for pat in patterns:
            if re.search(pat,text,re.I): find.append({'file':str(p.relative_to(ROOT)),'pattern':pat})
res={'package':'DIKWP ConsciousAgent BenchmarkLab 2026 V1','unsafe_capability_detected':bool(find),'findings':find,'note':'No production tool connection, external model, hidden telemetry or browser storage.'}
(ROOT/'static_boundary_audit_report.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(res,ensure_ascii=False,indent=2))
