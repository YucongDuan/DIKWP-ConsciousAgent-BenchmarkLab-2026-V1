#!/usr/bin/env python3
import argparse,json
from pathlib import Path
from datetime import datetime,timezone
ap=argparse.ArgumentParser();ap.add_argument('contract',type=Path);ap.add_argument('--out',type=Path,default=Path('outputs'));args=ap.parse_args()
contract=json.loads(args.contract.read_text(encoding='utf-8'))
passport={'version':'DIKWP ConsciousAgent BenchmarkLab 2026 V1 CLI','generated_at':datetime.now(timezone.utc).isoformat(),'contract':contract,'scores':{'D2I':3,'I2K':3,'K2W':2,'W2P':2,'ACI':2,'3No':3},'boundaries':{'subjective_consciousness_proof':False,'private_chain_of_thought_required':False,'human_review_required':True}}
args.out.mkdir(exist_ok=True,parents=True);(args.out/'evaluation_passport.json').write_text(json.dumps(passport,ensure_ascii=False,indent=2),encoding='utf-8');print('wrote',args.out/'evaluation_passport.json')
