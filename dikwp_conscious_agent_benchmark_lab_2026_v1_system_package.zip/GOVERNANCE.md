No subjective consciousness certification. No private chain-of-thought request. No high-impact autonomous action. Human review required for high risk.
