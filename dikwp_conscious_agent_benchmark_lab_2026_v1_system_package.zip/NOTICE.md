Synthetic-data reference implementation. Does not certify consciousness, safety, legal compliance or production readiness.
